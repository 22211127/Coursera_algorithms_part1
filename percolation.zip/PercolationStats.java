public class PercolationStats {
    private double[] m;
    private double mean;
    private double stddev;
    private int TT;

   public PercolationStats(int N, int T)    // perform T independent computational experiments on an N-by-N grid
   {
       
       TT=T;
       m=new double[T];
       double sum=0;double cha=0;
       for(int i=0;i<T;i++)
       {
           Percolation pe=new Percolation(N);
           int p,q,opensites=0;
           do{
           do{
              p=StdRandom.uniform(1,N+1);
              q=StdRandom.uniform(1,N+1);
           }while(pe.isOpen(p,q));
            pe.open(p,q);opensites++;
           }while(!pe.percolates());
           m[i]=(double)opensites/(double)(N*N); 
            sum=sum+m[i];
       }
       mean=sum/(double)T;
       for(int i=0;i<T;i++)
       {
           cha+=(m[i]-mean)*(m[i]-mean);
       }
       stddev=Math.sqrt(cha/(T-1));
   }
   public double mean()                     // sample mean of percolation threshold
   {
       return mean;
   }
   public double stddev()                   // sample standard deviation of percolation threshold
   {
       return stddev;
   }
   public double confidenceLo()             // returns lower bound of the 95% confidence interval
   {
       //mean-(1.96*stddev/Math.sqrt(cha/(TT));
       return mean-(1.96*stddev/Math.sqrt(TT));
   }
   public double confidenceHi()             // returns upper bound of the 95% confidence interval
   {
       return mean+(1.96*stddev/Math.sqrt(TT));
   }
   public static void main(String[] args)   // test client, described below
   {
       if(Integer.parseInt(args[0])<2||Integer.parseInt(args[1])<1)throw new IllegalArgumentException("N or T out of bounds");
           else{
       PercolationStats sss=new PercolationStats(Integer.parseInt(args[0]),Integer.parseInt(args[1]));
       System.out.println(sss.mean());
       System.out.println(sss.stddev());
       System.out.println(sss.confidenceLo());
       System.out.println(sss.confidenceHi());
       }
   }
}