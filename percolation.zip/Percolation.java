public class Percolation {
    private int[] op;
    private int temp;
    private int NN;
    private int[] isConnectButtom;
    private  WeightedQuickUnionUF uf;
        private int xyTo1D(int i, int j)
    {
            return (i-1)*temp+j-1;
    }
   public Percolation(int N)              // create N-by-N grid, with all sites blocked
   {
       if(N<=0)throw new IllegalArgumentException("N out of bounds");
       temp=N;
       NN=N*N;
       op=new int[NN+2];
       isConnectButtom=new int[NN+2];
       uf=new WeightedQuickUnionUF((NN+2));//NN+1 is virtual top ,NN+2 is virtual buttom
   }
   public void open(int i, int j)         // open site (row i, column j) if it is not already
   {
       if((i>0&&i<temp+1)&&(j>0&&j<temp+1))
       {
                  int isCB=0;
                  op[xyTo1D(i,j)]=1;
                  if(i>1&&isOpen(i-1,j)){
                      uf.union((i-1)*temp+j-1,(i-2)*temp+j-1);
                      if(isConnectButtom[uf.find((i-2)*temp+j-1)]==1)isCB=1;
                  }
                  if(i==1)
                  {
                      uf.union(xyTo1D(i,j),NN);
                  }
                  if(i<temp&&isOpen(i+1,j)){
                      uf.union((i-1)*temp+j-1,i*temp+j-1);
                      if(isConnectButtom[uf.find(i*temp+j-1)]==1)isCB=1;
                  }
                  if(j>1&&isOpen(i,j-1))
                  {
                      uf.union((i-1)*temp+j-1,(i-1)*temp+j-2);
                      if(isConnectButtom[uf.find((i-1)*temp+j-2)]==1)isCB=1;
                  }
                  if(j<temp&&isOpen(i,j+1))
                  {
                      uf.union((i-1)*temp+j-1,(i-1)*temp+j);   
                      if(isConnectButtom[uf.find((i-1)*temp+j)]==1)isCB=1;
                  }
                  if(i==temp)
                  {
                      isConnectButtom[uf.find(xyTo1D(i,j))]=1;
                  }
                  if(isCB==1)isConnectButtom[uf.find(xyTo1D(i,j))]=1;
       }
       else
       {
           throw new IndexOutOfBoundsException("row index i or cloumn index j out of bounds");
       }
   }
   public boolean isOpen(int i, int j)    // is site (row i, column j) open?
   {
        if(i<1||i>temp||j<1||j>temp)throw new IndexOutOfBoundsException("row index i or cloumn index j out of bounds");
        if(op[xyTo1D(i,j)]==1)return true;
        else return false;
   }
   public boolean isFull(int i, int j)    // is site (row i, column j) full?
   {
       if(i<1||i>temp||j<1||j>temp)throw new IndexOutOfBoundsException("row index i or cloumn index j out of bounds");
       if(i==1)
       {
           if(isOpen(i,j))
           return true;
              else return false;
       }
       int index=xyTo1D(i,j);
       if(i==temp&&uf.connected(index,NN))uf.union(index,NN+1);
       if(uf.connected(xyTo1D(i,j),NN))return true;
       return false;
   }
   public boolean percolates()            // does the system percolate?
   {
       if(isConnectButtom[uf.find(NN)]==1)return true;
       return false;     
   }
}