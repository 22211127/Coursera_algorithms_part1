import java.util.LinkedList;
import java.util.Queue;
import java.util.*;
import java.util.Arrays;
public class Solver {
    private int mv;
    private boolean sol;
    private Queue<Board> boardSeq;
    public Solver(Board initial) {           // find a solution to the initial board (using the A* algorithm)
        MinPQ<SearchNode> minPQ1 = new MinPQ<SearchNode>();
        MinPQ<SearchNode> minPQ2 = new MinPQ<SearchNode>();
        Set ts1 = new TreeSet();
        Set ts2 = new TreeSet();
        SearchNode sN = new SearchNode(initial);
        Board twin=initial.twin();
        SearchNode tw = new SearchNode(twin);
        Board ini=initial;
        ts1.add(new CloseBoard(ini));
        ts2.add(new CloseBoard(twin));
        mv = 0;
        while (!ini.isGoal() || !twin.isGoal()) {
            mv++;
            Queue<Board> iter1=(Queue<Board>)ini.neighbors();
            Queue<Board> iter2=(Queue<Board>)twin.neighbors();
            do{
                Board temp1=iter1.poll(); 
                Board temp2=iter2.poll();
                if (temp1 != null && !ts1.contains(new CloseBoard(temp1))) {
                    SearchNode temp11 = new SearchNode(temp1);
                    temp11.move+=mv;
                    temp11.parent=ini;
                    temp11.pre= sN;
                    ts1.add(new CloseBoard(temp1));
                    minPQ1.insert(temp11);
                }
                if (temp2 != null && !ts2.contains(new CloseBoard(temp2))) {
                    SearchNode temp22 = new SearchNode(temp2);
                    temp22.move+=mv;
                    temp22.parent=twin;
                    temp22.pre = tw;
                    ts2.add(new CloseBoard(temp2));
                    minPQ2.insert(temp22);
                }
            } while((iter1.peek() != null) || (iter2.peek() != null));
            sN = minPQ1.delMin();
            ini = sN.toBoard();
            tw = minPQ2.delMin();
            twin = tw.toBoard();
        }
        if (ini.isGoal() == true ){
            sol = true;
            boardSeq = new LinkedList<Board>();
            do {
                boardSeq.offer(sN.searchNode);
                sN = sN.pre;
            } while(sN != null);
        }
        else sol = false;
            
        
    }
    public boolean isSolvable() {            // is the initial board solvable?
        return sol;
    }
    public int moves() {                      // min number of moves to solve initial board; -1 if no solution
        return mv;
    }
    public Iterable<Board> solution() {      // sequence of boards in a shortest solution; null if no solution
//        boardSeq = new LinkedList<Board>();
        
        return (Iterable) boardSeq;
    }
    public static void main(String[] args) { // solve a slider puzzle (given below)
            // create initial board from file
    In in = new In(args[0]);
    int N = in.readInt();
    int[][] blocks = new int[N][N];
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            blocks[i][j] = in.readInt();
    Board initial = new Board(blocks);

    // solve the puzzle
    Solver solver = new Solver(initial);

    // print solution to standard output
    if (!solver.isSolvable())
        StdOut.println("No solution possible");
    else {
        StdOut.println("Minimum number of moves = " + solver.moves());
        for (Board board : solver.solution())
            StdOut.println(board);
    }
    }
}
class SearchNode implements Comparable<SearchNode>{
    public Board searchNode;
    public int manhattan;
    public Board parent; 
    public SearchNode pre;
    public int move;
    public SearchNode(Board initial) {
        searchNode = initial;
        move = 0;
        manhattan = initial.manhattan();
    }
    public int compareTo(SearchNode that)
    {
        SearchNode t = that;
        if (manhattan + move < t.manhattan + t.move) return -1;
        else if(manhattan + move > t.manhattan + t.move) return +1;
        else return 0;
    }
    public Board toBoard()
    {
        return searchNode;
    }
}
class CloseBoard implements Comparable<CloseBoard> {
    public Board b;
    public CloseBoard(Board initial) {
        b = initial;
    }
     public int compareTo(CloseBoard that)
    {
         
         if ( b == that.b) return 0;
         else return 1;
    }
}
