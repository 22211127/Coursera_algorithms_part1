import java.util.LinkedList;
import java.util.Queue;
public class Board {
    private int N;
    private char[][] b;
    private int[][] B;
    public Board(int[][] blocks)  {         // construct a board from an N-by-N array of blocks
        // (where blocks[i][j] = block in row i, column j)
        N = blocks[0].length;
        b=new char[N][N];
        for(int i = 0; i < N; i++)
            for(int j = 0; j < N; j++)
        {
            b[i][j] = (char)blocks[i][j];
        }
        B=blocks;
    }
    public int dimension() {                // board dimension N
        return N;
    }
    public int hamming() {                 // number of blocks out of place
        int x = 0;
        for(int i = 0; i < N; i++)
            for(int j = 0; j < N; j++)
        {
            if (b[i][j] != (i*N+j+1)) x++;
        }
        return x;
    }
    public int manhattan() {               // sum of Manhattan distances between blocks and goal
        int x = 0;
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
        {
            if (b[i][j] == 0) break;
            int i1 = (b[i][j]-2)/N;int j1 = b[i][j]-i1*N-1;
            if (i1 > i) {
                if (j1 > j) x = x + i1 - i + j1 - j;
                else x = x + i1 -i + j - j1;
            }
            else {
                if (j1 > j) x = x + i - i1 + j1 - j;
                else x = x + i - i1 + j - j1;
            }
        }
        return x;
    }
    public boolean isGoal() {              // is this board the goal board?
        if (this.hamming() == 0) return true;
        else return false;
    }
    public Board twin() {                   // a board obtained by exchanging two adjacent blocks in the same row
        int[][] t=new int[N][N];
        if( b[0][0] != 0 && b[0][1] !=0){
            for(int i = 0; i < N; i++)
                for(int j = 0; j < N; j++)
            {
                if (i == 0 && j == 0)t[i][j] = b[0][1];
                else if(i == 0 && j == 1)t[i][j] = b[0][0];
                else
                    t[i][j] = b[i][j];
            }
        }
        else {
            for(int i = 0; i < N; i++)
                for(int j = 0; j < N; j++)
            {
                if (i == 1 && j == 0)t[i][j] = b[1][1];
                else if(i == 1 && j == 1)t[i][j] = b[1][0];
                else
                    t[i][j] = b[i][j];
            }
        }
        Board bo = new Board(t);
        return bo;
    }
    public boolean equals(Object y) {      // does this board equal y?
        if (y == this) return true;
        if (y == null) return false;
        if (y.getClass() != this.getClass()) return false;
        Board that = (Board) y;
        for(int i = 0; i < N; i++)
            for(int j = 0; j < N; j++)
        {
            if (this.b[i][j] != that.b[i][j]) return false;
        }
        return true;
        
    }
    public Iterable<Board> neighbors() {   // all neighboring boards
        Queue<Board> boardSeq = new LinkedList<Board>();
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
        {
            if (this.b[i][j] == 0)
            {
                if (i-1 >= 0) {
                    Board t =new Board(B);
                    t.swap(i,j,i-1,j);
                    boolean k=boardSeq.offer(t);
                    if (k == false) System.out.println("queue is full");
                }
                if (i+1 < N) {
                    Board t =new Board(B);
                    t.swap(i,j,i+1,j);
                    boolean k=boardSeq.offer(t);
                    if (k == false) System.out.println("queue is full");
                }
                if (j-1 >= 0) {
                    Board t =new Board(B);
                    t.swap(i,j,i,j-1);
                    boolean k=boardSeq.offer(t);
                    if (k == false) System.out.println("queue is full");
                }
                if (j+1 <N) {
                    Board t =new Board(B);
                    t.swap(i,j,i,j+1);
                    boolean k=boardSeq.offer(t);
                    if (k == false) System.out.println("queue is full");
                }
            }
        }
        return (Iterable) boardSeq;
    }
    private void swap(int i,int j,int x,int y)
    {
        char temp = b[i][j];
        b[i][j] = b[x][y];
        b[x][y] = temp;
    }
    public String toString() {              // string representation of the board (in the output format specified below)
        StringBuilder s = new StringBuilder();
        s.append(N + "\n");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                s.append(String.format("%2d ", B[i][j]));
            }
            s.append("\n");
        }
        return s.toString();
    }
    public static void main(String[] args) { // solve a slider puzzle (given below)
        // create initial board from file
        In in = new In(args[0]);
        int N = in.readInt();
        int[][] blocks = new int[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
            blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);
        StdOut.println(initial.toString());
        StdOut.println(initial.manhattan());
        StdOut.println(initial.hamming());
        initial = initial.twin();
        StdOut.println(initial.toString());
        StdOut.println(initial.manhattan());
        StdOut.println(initial.hamming());
    }
}
