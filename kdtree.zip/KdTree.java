import java.util.LinkedList;
import java.util.Queue;
public class KdTree {
    private int N;
    private Node root;
    public KdTree() {                              // construct an empty set of points
        N = 0;
    }
    public boolean isEmpty() {                       // is the set empty?
        return N == 0;
    }
    public int size() {                              // number of points in the 
        return N;
    }
    public void insert(Point2D p) {                  // add the point p to the set (if it is not already in the set)
        if (N == 0)
        {
            root = new Node();
            root.p = p;
//            root.rect = new RectHV(0,0,1,1); 
            N++;
        }
        else if (!contains(p)) {
            Node i = root;
            if (p.x() < root.p.x())
                i.lb=insert(i.lb,p,'y');
            else i.rt=insert(i.rt,p,'y');
        }
    }
    private Node insert(Node i,Point2D p,char ori)
    {
        if (i == null) {
            i = new Node();
            i.p = p;
            N++;
            return i;
        }
        else {
            if (ori == 'y') {
                if (p.y() < i.p.y()) {
                    i.lb = insert(i.lb,p,'x');
                    return i;
                }
                else {
                    i.rt = insert(i.rt,p,'x');
                    return i;
                }
            }
            else if (ori == 'x') {
                if (p.x() < i.p.x()) {
                    i.lb = insert(i.lb,p,'y');
                    return i;
                }
                else {
                    i.rt = insert(i.rt,p,'y');
                    return i;
                }
            }
            else throw new  IllegalArgumentException("illegal argument:not x or y ");
            
        }
    }
    public boolean contains(Point2D p) {             // does the set contain the point p?
        return (this.get(root,p,'x') != null);
    }
    private Point2D get(Node r,Point2D p,char ori) {
        if (r == null) return null;
        else if (r.p.equals(p) == true) return r.p;
        else if (ori == 'x'){
            if (p.x() < r.p.x())
                return get(r.lb,p,'y');
            else return get(r.rt,p,'y');
        }
        else if (ori == 'y') {
            if (p.y() < r.p.y())
                return get(r.lb,p,'x');
            else return get(r.rt,p,'x');
        }
        else throw new  IllegalArgumentException("illegal argument:not x or y ");     
    }
    public void draw() {                             // draw all of the points to standard draw
        draw(root,'y',0,1,0,1);
    }
    private void draw(Node r,char ori,double x1,double x2,double y1,double y2)
    {
        if (r != null) {
            if (ori == 'y') {
                StdDraw.setPenColor(StdDraw.BLACK);
                StdDraw.setPenRadius(.01);
                r.p.draw();
                StdDraw.setPenColor(StdDraw.RED);
                StdDraw.setPenRadius();
                StdDraw.line(r.p.x(), y1, r.p.x(), y2);
                draw(r.lb,'x',x1,r.p.x(),y1,y2);
                draw(r.rt,'x',r.p.x(),x2,y1,y2);
            }
            else if (ori == 'x') {
                StdDraw.setPenColor(StdDraw.BLACK);
                StdDraw.setPenRadius(.01);
                r.p.draw();
                StdDraw.setPenColor(StdDraw.BLUE);
                StdDraw.setPenRadius();
                StdDraw.line(x1, r.p.y(),x2, r.p.y());
                draw(r.lb,'y',x1,x2,y1,r.p.y());
                draw(r.rt,'y',x1,x2,r.p.y(),y2);
            }
            else throw new  IllegalArgumentException("illegal argument:not x or y ");     
        }
    }
    public Iterable<Point2D> range(RectHV rect) {    // all points in the set that are inside the rectangle
        Queue<Point2D> r = new LinkedList<Point2D>();
        range(r,rect,'x',root,0,1,0,1);
//        rect.distanceTo(t) == 0.0
        return r;
    }
    private void range(Queue<Point2D> r,RectHV rect,char ori,Node n,double x1,double x2,double y1,double y2)
    {
        if (n != null) {
            if (rect.contains(n.p)) r.offer(n.p);
            if (n.lb != null) {
                if (ori == 'x' && rect.intersects(new RectHV(x1,y1,n.p.x(),y2))) range(r,rect,'y',n.lb,x1,n.p.x(),y1,y2);
                else if (ori == 'y' && rect.intersects(new RectHV(x1,y1,x2,n.p.y()))) range(r,rect,'x',n.lb,x1,x2,y1,n.p.y());
                //else throw new  IllegalArgumentException("illegal argument:not x or y ");     
                
            }
            if (n.rt != null) {
                if (ori == 'x' && rect.intersects(new RectHV(n.p.x(),y1,x2,y2))) range(r,rect,'y',n.rt,n.p.x(),x2,y1,y2);
                else if (ori == 'y' && rect.intersects(new RectHV(x1,n.p.y(),x2,y2))) range(r,rect,'x',n.rt,x1,x2,n.p.y(),y2);
                //else throw new  IllegalArgumentException("illegal argument:not x or y ");
            }
            }

    }
    public Point2D nearest(Point2D p)   {            // a nearest neighbor in the set to p; null if set is empty
        if (N == 0) return null;
        Point2D closest = nearest(root.p,p,'x',root,0,1,0,1);
        return closest;
    }   
    private Point2D nearest(Point2D closest,Point2D p,char ori,Node n,double x1,double x2,double y1,double y2) {
        
        if (n.p.distanceTo(p) < closest.distanceTo(p)) closest = n.p;
        
        if(ori == 'x') {
            if (p.x() < n.p.x()) {
                if (n.lb != null && (closest.distanceTo(p) > (new RectHV(x1,y1,n.p.x(),y2)).distanceTo(p))) 
                    closest = nearest(closest,p,'y',n.lb,x1,n.p.x(),y1,y2);
                if (n.rt != null && (closest.distanceTo(p) > (new RectHV(n.p.x(),y1,x2,y2)).distanceTo(p))) 
                    closest = nearest(closest,p,'y',n.rt,n.p.x(),x2,y1,y2);
            }
            else {
                if (n.rt != null && (closest.distanceTo(p) > (new RectHV(n.p.x(),y1,x2,y2)).distanceTo(p))) 
                    closest = nearest(closest,p,'y',n.rt,n.p.x(),x2,y1,y2);
                if (n.lb != null && (closest.distanceTo(p) > (new RectHV(x1,y1,n.p.x(),y2)).distanceTo(p))) 
                    closest = nearest(closest,p,'y',n.lb,x1,n.p.x(),y1,y2);
            }
        }
        else if(ori =='y') {
            if (p.y() < n.p.y()) {
                if (n.lb != null && (closest.distanceTo(p) > (new RectHV(x1,y1,x2,n.p.y())).distanceTo(p))) 
                    closest = nearest(closest,p,'x',n.lb,x1,x2,y1,n.p.y());
                if(n.rt != null && (closest.distanceTo(p) > (new RectHV(x1,n.p.y(),x2,y2)).distanceTo(p))) 
                    closest = nearest(closest,p,'x',n.rt,x1,x2,n.p.y(),y2);
            }
            else {
                if (n.rt != null && (closest.distanceTo(p) > (new RectHV(x1,n.p.y(),x2,y2)).distanceTo(p))) 
                    closest = nearest(closest,p,'x',n.rt,x1,x2,n.p.y(),y2);
                if (n.lb != null && (closest.distanceTo(p) > (new RectHV(x1,y1,x2,n.p.y())).distanceTo(p))) 
                    closest = nearest(closest,p,'x',n.lb,x1,x2,y1,n.p.y());
            }
        }
        
        
//        if (n.lb != null) {
//            if (ori == 'x' && (closest.distanceTo(p) > (new RectHV(x1,y1,n.p.x(),y2)).distanceTo(p))) 
//                closest = nearest(closest,p,'y',n.lb,x1,n.p.x(),y1,y2);
//            else if (ori == 'y' && (closest.distanceTo(p) > (new RectHV(x1,y1,x2,n.p.y())).distanceTo(p))) 
//                closest = nearest(closest,p,'x',n.lb,x1,x2,y1,n.p.y());
//
//        }
//        if (n.rt != null) {
//            if (ori == 'x' && (closest.distanceTo(p) > (new RectHV(n.p.x(),y1,x2,y2)).distanceTo(p))) 
//                closest = nearest(closest,p,'y',n.rt,n.p.x(),x2,y1,y2);
//            else if (ori == 'y' && (closest.distanceTo(p) > (new RectHV(x1,n.p.y(),x2,y2)).distanceTo(p))) 
//                closest = nearest(closest,p,'x',n.rt,x1,x2,n.p.y(),y2);
//        }
        return closest;
        
    }       
    public static void main(String[] args) {
        String filename = args[0];
        In in = new In(filename);

        StdDraw.show(0);
        
        KdTree kdtree = new KdTree();
        while (!in.isEmpty()) {
            double x = in.readDouble();
            double y = in.readDouble();
            Point2D p = new Point2D(x, y);
            kdtree.insert(p);
        }
        kdtree.draw();
        StdDraw.show(0);
    }
}
    class Node {
        public Point2D p;      // the point
//        public RectHV rect;    // the axis-aligned rectangle corresponding to this node
        public Node lb;        // the left/bottom subtree
        public Node rt;        // the right/top subtree
        public Node()
        {
        }
    }


