import java.util.LinkedList;
import java.util.Queue;
import java.util.Iterator;
import java.util.TreeSet;
public class PointSET {
    private int N;
    private TreeSet<Point2D> first;
    public PointSET() {                              // construct an empty set of points
        N = 0;
        first = null;
    }
    public boolean isEmpty() {                       // is the set empty?
        return N==0;
    }
    public int size()   {                            // number of points in the set
        return N;
    }
    public void insert(Point2D p) {                  // add the point p to the set (if it is not already in the set)
        
        if ( N == 0) {
            first = new TreeSet<Point2D>();
            first.add(p);
            N++;
        }
        else {
            if (first.add(p)) N++;

        }
    }
    public boolean contains(Point2D p)  {            // does the set contain the point p?
      return first.contains(p);
    }
    public void draw()  {                            // draw all of the points to standard draw
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.setPenRadius(.01);
        Iterator<Point2D> x = first.iterator();
        while (x.hasNext()) 
        {
            Point2D t = x.next();
            t.draw();
        }
    }
    public Iterable<Point2D> range(RectHV rect)  {   // all points in the set that are inside the rectangle
        Queue<Point2D> r = new LinkedList<Point2D>();
        Iterator<Point2D> x = first.iterator();
        while (x.hasNext()) 
        {
            Point2D t = x.next();
            if (rect.distanceTo(t) == 0.0) r.offer(t);

        }
        return r;
    }
    public Point2D nearest(Point2D p) {               // a nearest neighbor in the set to p; null if set is empty
        if (N == 0) return null;
        Iterator<Point2D> x = first.iterator();
        Point2D min =x.next();
        while (x.hasNext()) 
        {
            Point2D t = x.next();
            if (p.distanceTo(min) > p.distanceTo(t)) min=t;
        }
        return min;
    }
}

class point {
    public Point2D p;
    public point next;
    public point(Point2D i) {
        p = i;
        next = null;
    }
}