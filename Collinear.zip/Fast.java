import java.util.Arrays;
public class Fast {
    private Point p;
    private Fast next;
    public static void main(String[] args)
    {
        Fast first=null;
        In in = new In(args[0]);
        int N = in.readInt();
        Point[] p=new Point[N];
        for (int i = 0; i < N; i++) {
            int x = in.readInt();
            int y = in.readInt();
            p[i] = new Point(x, y);
            p[i].draw();
        }
        Arrays.sort(p);
//        for (int i = 0; i< N;i++)
//        {
//            System.out.print(p[i]);
//        }
//        System.out.println("");
        int n = N;
        for (int k = 0; k < N-2; k++,n--)
        {
            Point[] aux = new Point[n-1];
            for (int i = 0,x =k+1; i< n-1; i++,x++)
            {
                //if(x == k) x++;
                aux[i]=p[x];
            }
            Point temp = p[k];
            Arrays.sort(aux,temp.SLOPE_ORDER);
//            System.out.println("temp-key:"+temp);
//            for (int i = 0; i< n-1;i++)
//            {
//                System.out.print(aux[i]+"|");
//                System.out.print("slope-key:"+temp.slopeTo(aux[i]));
//            }
//            System.out.println("");
            for (int i = 0, y = 0; i < n-2 || y >= 2; i++)
            {
                if ((i < n-2) && temp.slopeTo(aux[i]) == temp.slopeTo(aux[i+1])) y++;
                else if (y >= 2) {
                    int w=0;
                    if (first != null)
                    {
                        Fast t = first;
                         do{
                            if (t.p.slopeTo(temp)==temp.slopeTo(aux[i-y]))
                            {
                                w=1;
                                y=0;
                                break;
                            }
                            t=t.next;
                        } while (t != null);
                    }
                    if (w == 1) break;
                    Fast t=first;
//                    while(t.next!=null)t=t.next;
                    Fast d=new Fast();
                    d.p=temp;
                    if (first == null) first=d;
                    else 
                    {
                        while(t.next!=null)t=t.next;
                        t.next=d;
                    }
                    System.out.print(temp);
                    for(int x = y+1; x > 0; x--)
                    {
                        System.out.print(" -> "+aux[i-x+1]);
                    }
                    System.out.println("");
                    temp.drawTo(aux[i]);
                    y=0;
                }
                else y=0;
            }
        }
    }
    private class Node{
        Point a;
        Node next=null;
        Node(Point s)
        {
            a=s;
        }
    }
}