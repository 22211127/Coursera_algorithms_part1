/*************************************************************************
 * Name:cair
 * Email:22211127@163.com
 *
 * Compilation:  javac Point.java
 * Execution:
 * Dependencies: StdDraw.java
 *
 * Description: An immutable data type for points in the plane.
 *
 *************************************************************************/

import java.util.Comparator;

public class Point implements Comparable<Point> {

    // compare points by slope
    public final Comparator<Point> SLOPE_ORDER = new PolarOrder();       // YOUR DEFINITION HERE

    private final int x;                              // x coordinate
    private final int y;                              // y coordinate

    // create the point (x, y)
    public Point(int x, int y) {
        /* DO NOT MODIFY */
        this.x = x;
        this.y = y;
    }
    private class PolarOrder implements Comparator<Point>
    {
//        public int compare(Point q1,Point q2)
//        {
//            double dy1 = q1.y - y;
//            double dy2 = q2.y - y;
//            if      (dy1 == 0 && dy2 ==0) {return 0;}  //p, q1 ,q2 horizontal
//            else if (dy1 >= 0 && dy2 < 0) return +1;
//            else if (dy2 >= 0 && dy1 < 0) return -1;
//            else return -ccw(Point.this,q1,q2);
//        }
         public int compare(Point q1,Point q2)
         {
             double t1 = Point.this.slopeTo(q1);
             double t2 = Point.this.slopeTo(q2);
             if (t1 > t2) return 1;
             else if (t1 < t2) return -1;
             else return 0;
         }
        
    }
//    private static int ccw(Point a,Point b,Point c) {
//        double area2 = (b.x-a.x)*(c.y-a.y) -(b.y-a.y)*(c.x-a.x);
//        if (area2 < 0) return -1;
//        else if (area2 > 0) return +1;
//        else return 0;    //collinear
//    }

    // plot this point to standard drawing
    public void draw() {
        /* DO NOT MODIFY */
        StdDraw.point(x, y);
    }

    // draw line between this point and that point to standard drawing
    public void drawTo(Point that) {
        /* DO NOT MODIFY */
        StdDraw.line(this.x, this.y, that.x, that.y);
    }
    
    // slope between this point and that point
    public double slopeTo(Point that) {
        /* YOUR CODE HERE */
        if ( this.x == that.x ) {
            if ( this.y == that.y) return Double.NEGATIVE_INFINITY;
            else return Double.POSITIVE_INFINITY;
            //return Double.POSITIVE_INFINITY;
        }
        else if ( this.y == that.y) {
            //if ( that.x-this.x <0  ) return -0;
            //else return +0;
            return 0;
        }
        double result=((double)(that.y-this.y) /(double)(that.x-this.x));
        return result;
    }

    // is this point lexicographically smaller than that one?
    // comparing y-coordinates and breaking ties by x-coordinates
    public int compareTo(Point that) {
        /* YOUR CODE HERE */
        if ( this.y < that.y ) return -1;
        else if ( this.y > that.y ) return +1;
        else {
            if ( this.x < that.x ) return -1;
            else if ( this.x> that.x) return +1;
            else return 0;
        }
    }

    // return string representation of this point
    public String toString() {
        /* DO NOT MODIFY */
        return "(" + x + ", " + y + ")";
    }

    // unit test
    public static void main(String[] args) {
        /* YOUR CODE HERE */
        Point p = new Point(38, 257);//-ccw  -1 true:-1
        Point q = new Point(147, 106);
        Point r = new Point(355, 86);
//         Point p = new Point(13132, 28506);//1 true:1
//        Point q = new Point(7407, 28522);
//        Point r = new Point(27588, 4723);
//         Point p = new Point(359, 434);//-ccw 1 true:1
//        Point q = new Point(314, 234);
//        Point r = new Point(20, 408);
//        Point p = new Point(381, 282); // -1  true:1
//        Point q = new Point(292, 10);
//        Point r = new Point(451, 364);
//        Point p = new Point(7975, 1993);//-ccw 1      true:-1
//        Point q = new Point(1303, 23240);
//        Point r = new Point(26960, 30055);
        System.out.println( p.SLOPE_ORDER.compare(q, r));
    }
}
