import java.util.Arrays;
public class Brute {
   public static void main(String[] args)
   {
       In in = new In(args[0]);
       int N = in.readInt();
       Point[] p=new Point[N];
       for (int i = 0; i < N; i++) {
            int x = in.readInt();
            int y = in.readInt();
            p[i] = new Point(x, y);
            p[i].draw();
        }
        Arrays.sort(p);
/*        for (int i = 0; i < N; i++) {
        System.out.print(p[i]);
        }
        System.out.println("");*/
//        Point[] aux = new Point[N];
//        aux = p;
        for (int k = 0; k < N; k++) {
            for (int i = k+1; i < N; i++) {
                for (int j = i+1; j < N; j++) {
                    for (int x = j+1;x < N; x++) {
                        //System.out.println(p[k].slopeTo(p[i])+"--"+p[k].slopeTo(p[j])+"--"+p[k].slopeTo(p[i])+"--"+p[k].slopeTo(p[x]));
                        if ((p[k].slopeTo(p[i]) == p[k].slopeTo(p[j]) )&&( p[k].slopeTo(p[i]) == p[k].slopeTo(p[x]))){
                         System.out.println(p[k]+" -> "+p[i]+" -> "+p[j]+" -> "+p[x]);
                         p[k].drawTo(p[x]);
                        }
                    }
                }
            }
        }
        
        
   }
}