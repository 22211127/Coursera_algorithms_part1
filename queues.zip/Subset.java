import java.util.Iterator;
public class Subset {
    public static void main(String[] args) {
        RandomizedQueue<String> s = new RandomizedQueue<String>();
        int k = Integer.parseInt(args[0]);
 while (!StdIn.isEmpty()) {
 String item = StdIn.readString();
 s.enqueue(item);
 }
// System.out.println(s.size());
 Iterator iter = s.iterator();
for (int i = 0; i < k; i++) {
     if (iter.hasNext())
 StdOut.println(iter.next());
    }
    }
}