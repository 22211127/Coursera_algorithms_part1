import java.util.Iterator;
import java.util.NoSuchElementException;
public class Deque<Item> implements Iterable<Item> {
    private int number = 0;
    private Node first;
    private Node last;
    // construct an empty deque
   public Deque() {
       number = 0;
   }
    // is the deque empty?
   public boolean isEmpty() {
       if (number == 0) return true;
       return false;
   }
    // return the number of items on the deque
   public int size() { 
       return number;
   }
   // insert the item at the front
   public void addFirst(Item item) {
       if (item == null) throw new NullPointerException();
       if (number == 0) {
           Node N = new Node();
           N.item = item;
           first = N;
           last = N;
       }
       else {
           Node N = new Node();
           N.item = item;
           N.next = first;
           first.pre = N;
           first = N;
       }
       number++;
   }
   // insert the item at the end
   public void addLast(Item item) {
        if (item == null)throw new NullPointerException();
         if (number == 0) {
           Node N = new Node();
           N.item = item;
           first = N;
           last = N;
       }
       else {
           Node N = new Node();
           N.item = item;
           N.pre = last;
           last.next = N;
           last = N;
       }
       number++;
   }
   // delete and return the item at the front
   public Item removeFirst() {
       if (number == 0)throw new NoSuchElementException();
       else {
           Item a = first.item;
           Node N = first;
           if (first.next != null)first = first.next;
           N.next = null;
           first.pre = null;
           number--;
           return a;
       }
   }
   // delete and return the item at the end
   public Item removeLast() {
       if (number == 0)throw new NoSuchElementException();
       else {
           Item a = last.item;
           Node N = last;
           if (last.pre != null)last = last.pre;
           N.pre = null;
           last.next = null;
           number--;
           return a;
       }
   }
   // return an iterator over items in order from front to end
   public Iterator<Item> iterator() {
       return new ListIterator();
   }
   private class ListIterator implements Iterator<Item> {
       private Node current = new Node();
       public ListIterator() {
           if (number > 0)current.next = first;
       }
       public Item next() {
           if (!hasNext()) throw new NoSuchElementException();
           //Item item = current.item;
           current = current.next; 
           return current.item; 
       }
       public void remove() {
       throw new UnsupportedOperationException();
       }
       public boolean hasNext() {
           return current.next != null;
       }
   }
   // unit testing
   public static void main(String[] args) {
        Deque<String> s = new Deque<String>();
        for (int i = 0; i < args.length; i++)
       {
            String item = args[i];
            s.addFirst(item);
           // else if (!s.isEmpty()) StdOut.print(s.pop() + " ");
        }
//        System.out.println(s.size());
        Iterator iter = s.iterator();
        do
        {
            String str = (String) iter.next();
  System.out.println(str); 
        } while(iter.hasNext());
        StdOut.println("(" + s.size() + " left on que)");
   }
   private class Node {
    //Item item = (Item) new Object[1];
    private Item item;
    private Node pre = null;
    private Node next = null;
}
}
