import java.util.Iterator;
import java.util.NoSuchElementException;
public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] a;         // array of items
    private int N;
//    private int head=0,tail=0;
   // construct an empty randomized queue
    public RandomizedQueue() {
        a = (Item[]) new Object[2];
    }
    // is the queue empty?
    public boolean isEmpty() {
        return N == 0;
    }
    // return the number of items on the queue
    public int size() {
        return N;
    }
    public void enqueue(Item item) {
        if (item == null)throw new NullPointerException();
        if (N == a.length) resize(2*a.length);
        a[N++] = item;
    }
    // delete and return a random item
    public Item dequeue() {
        if (isEmpty()) throw new NoSuchElementException("RandomizedQueue underflow");
     //   StdRandom.shuffle(a,0,N-1);
          int x = StdRandom.uniform(N);
            Item temp = a[x];
            a[x] = a[N-1];
            N--;
  //          if (N > 0 && N == a.length/4) resize(a.length/2);
            return temp;
    }
    public Item sample() {
        if (isEmpty()) throw new NoSuchElementException("RandomizedQueue underflow");
        int x = StdRandom.uniform(N);
        return a[x];
    }
    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator();
    }
    private class RandomizedQueueIterator implements Iterator<Item> {
        private int i;
        private Item[] b;
    //    StdRandom.shuffle(b,0,tail);
        public RandomizedQueueIterator() {
            i = N;
            b = (Item[]) new Object[a.length];
            for (int x = 0; x < N; x++) {
            b[x] = a[x];
        }
            if (N != 0)
            StdRandom.shuffle(b, 0, N-1);
        }
        public boolean hasNext() {
            return i > 0;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            return b[--i];
        }
    }
    private void resize(int capacity) {
        assert capacity >= N;
        Item[] temp = (Item[]) new Object[capacity];
        for (int i = 0; i < N; i++) {
            temp[i] = a[i];
        }
        a = temp;
    }
       // unit testing
    public static void main(String[] args) {
        RandomizedQueue<String> s = new RandomizedQueue<String>();
        for (int i = 0; i < args.length; i++)
       {
            String item = args[i];
            s.enqueue(item);
           // else if (!s.isEmpty()) StdOut.print(s.pop() + " ");
        }
//        System.out.println(s.size());
        Iterator iter = s.iterator();
        while (iter.hasNext())
        { 
            String str = (String) iter.next();
  System.out.println(str); 
        }
        StdOut.println("(" + s.size() + " left on que)");
    }
}